# 将拼图游戏部署到GitHub Pages

以下是将您的拼图游戏部署到GitHub Pages的详细步骤，这样您就其他人人就可以通过真实的URL和二维码访问游戏。

## 前提条件

- 一个GitHub账号
- 基本的Git使用知识

## 步骤1：创建GitHub仓库

1. 登录您的GitHub账号
2. 点击右上角的"+"按钮，选择"New repository"
3. 仓库名称建议设置为 `puzzle-game` 或 `yuehe-puzzle-game`
4. 选择"Public"（公共仓库）
5. 勾选"Add a README file"
6. 点击"Create repository"

## 步骤2：准备游戏文件

确保您的游戏文件夹包含以下文件：
- `index.html` - 游戏主页面
- `qrcode-display.html` - 二维码展示页面
- `qrcode-generator.html` - 二维码生成器
- `README.md` - 说明文档

## 步骤3：上传游戏文件到GitHub

### 方法一：使用Git命令行

1. 打开命令提示符或终端
2. 导航到您的游戏文件夹：
   ```
   cd /path/to/puzzle-game
   ```

3. 初始化Git仓库：
   ```
   git init
   ```

4. 添加所有文件：
   ```
   git add .
   ```

5. 提交更改：
   ```
   git commit -m "Initial commit of puzzle game"
   ```

6. 连接到GitHub仓库：
   ```
   git remote add origin https://github.com/您的用户名/您的仓库名.git
   ```

7. 推送到GitHub：
   ```
   git push -u origin main
   ```

### 方法二：使用GitHub Desktop

1. 下载并安装GitHub Desktop
2. 点击"File" > "Clone repository"
3. 选择您刚刚创建的仓库
4. 将游戏文件复制到克隆的仓库文件夹中
5. 在GitHub Desktop中输入提交信息
6. 点击"Commit to main"
7. 点击"Push origin"

## 步骤4：启用GitHub Pages

1. 打开您的GitHub仓库页面
2. 点击顶部的"Settings"
3. 在左侧导航栏中找到并点击"Pages"
4. 在"Source"部分，从下拉菜单中选择"main"分支
5. 在文件夹选择中，选择"/ (root)"
6. 点击"Save"
7. 等待几分钟，您的网站将被部署

## 步骤5：获取您的游戏URL

部署完成后，您的游戏将可以通过以下URL访问：
```
https://您的用户名.github.io/您的仓库名/
```

例如：
```
https://username.github.io/puzzle-game/
```

## 步骤6：生成真实的二维码

1. 打开 `qrcode-generator.html` 文件
2. 输入您的GitHub Pages URL
3. 点击"生成"按钮
4. 右键点击生成的二维码，选择"Save image as..."保存图片
5. 您现在有了一个可以扫描的真实二维码

## 步骤7：更新二维码展示页面

1. 打开 `qrcode-display.html` 文件
2. 将二维码图片替换为您刚刚生成的真实二维码
3. 更新URL信息为您的GitHub Pages URL
4. 提交并推送这些更改到GitHub

## 完成！

现在您的拼图游戏已经部署到互联网上，任何人都可以通过您的GitHub Pages URL或扫描二维码来访问和玩这个游戏。

## 注意事项

- GitHub Pages可能需要几分钟时间来更新您的更改
- 确保所有图片和资源路径都是相对路径，而不是绝对路径
- 如果您遇到任何问题，请检查浏览器的开发者工具控制台以获取错误信息
- 您可以通过添加自定义域名来使URL更加专业（需要购买域名）
